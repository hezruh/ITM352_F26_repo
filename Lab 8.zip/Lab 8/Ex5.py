isIt = "ho-oh"
isItCheck = ""
print(isIt)

def is_palindrome(isIt, isItCheck):
    for letters in range(len(isIt), 0, -1):
        #isItCheck = isItCheck + isIt[letters - 1]
        #print(isItCheck)
    #return isItCheck == isIt
        if (isIt[letters - 1] != isIt[len(isIt) - letters]):
            return False
        else:
            return True

print(is_palindrome(isIt, isItCheck))
print(isItCheck)